#pragma once
class NullException
{
};

