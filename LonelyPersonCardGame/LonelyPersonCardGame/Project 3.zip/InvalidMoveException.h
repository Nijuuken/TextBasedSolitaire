#pragma once
class InvalidMoveException
{
};